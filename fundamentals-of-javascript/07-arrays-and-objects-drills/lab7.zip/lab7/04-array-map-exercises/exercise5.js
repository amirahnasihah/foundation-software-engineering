// Task: Count Letters for each of the name in the array of object

const countLetters = (arr) => {
    // Add your code here

}

// DO NOT EDIT CODE BELOW
// Test Cases:
console.log(countLetters([
    { name: "Peter Chan", age: 22 },
    { name: "Darren Chiu", age: 12 },
    { name: "Paul Lau", age: 5 },
    { name: "Erika Lee", age: 30 },
    { name: "Anthony Wong", age: 16 }
]));

// Expected Output
// [10, 11, 8, 9, 12]