// Task: Build an array of people introduction with their name and age

const buildIntroStrings  = (arr) => {
    // Add your code here

}

// DO NOT EDIT CODE BELOW
// Test Case:
console.log(buildIntroStrings([
    { name: "Peter Chan", age: 22 },
    { name: "Darren Chiu", age: 12 },
    { name: "Paul Lau", age: 5 },
    { name: "Erika Lee", age: 30 },
    { name: "Anthony Wong", age: 16 }
]));

// Expected Output
// ["Peter Chan is 22 years old.", 
// "Darren Chiu is 12 years old.", 
// "Paul Lau is 5 years old.", 
// "Erika Lee is 30 years old.", 
// "Anthony Wong is 16 years old."]