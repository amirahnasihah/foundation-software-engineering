// Task: Extract the name from the list of objects

const namesOnly = (arr) => {
  // Add your code here

}
  
// DO NOT EDIT CODE BELOW
// Test Cases
console.log(namesOnly([
  { name: "Peter Chan", age: 22 },
  { name: "Darren Chiu", age: 12 },
  { name: "Paul Lau", age: 5 },
  { name: "Erika Lee", age: 30 },
  { name: "Anthony Wong", age: 16 }
])); 

// Expected Output
// ["Peter Chan", "Darren Chiu", "Paul Lau", "Erika Lee", "Anthony Wong"]