// Task: Write a JavaScript function to remove a specific element from an array.
// You can assume that there are 1 and only 1 existence of the target in the array
// Hint: You might want to check the documentation of array.splice() function

const remove_array_element = (array, target) => {
    // Add your code here

}


// DO NOT EDIT CODE BELOW
// Test Case
let array1 = [2, 5, 9, 6]
remove_array_element(array1, 5)
console.log(array1);

// Expected Output
// [2, 9, 6]