// Task: Make a filtered list of all the people who are over 18

const ageOver18 = (arr) => {
  // Add your code here

}

// DO NOT EDIT CODE BELOW
// Test Cases:
console.log(JSON.stringify(ageOver18([
  { name: "Peter Chan", age: 22 },
  { name: "Darren Chiu", age: 12 },
  { name: "Paul Lau", age: 5 },
  { name: "Erika Lee", age: 30 },
  { name: "Anthony Wong", age: 16 }
]))); 

// Expected Output: 
//[ { name: 'Peter Chan', age: 22 },
//  { name: 'Erika Lee', age: 30 } ]