// Task: Given an array of strings, return a new array that only includes those that are 6 characters or fewer in length
// Tips: You might want to look for ways to get string length from Google.

const sixCharactersOrFewerOnly = (arr) => {
  // Add your code here

}

// DO NOT EDIT CODE BELOW
// Test Cases
console.log(sixCharactersOrFewerOnly(["pet", "malay", "USA", "PeterPan", "Hello", "shopping"]));

// Expected Output
// ["pet", "malay", "USA", "Hello"]
